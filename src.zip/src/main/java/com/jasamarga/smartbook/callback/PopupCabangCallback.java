package com.jasamarga.smartbook.callback;

/**
 * Created by apridosandyasa on 8/9/16.
 */
public interface PopupCabangCallback {
    void onPopupCabangCallback(CharSequence title);
}
