package com.jasamarga.smartbook.callback;

import java.io.Serializable;

/**
 * Created by apridosandyasa on 8/8/16.
 */
public interface MainBottomContentAdapterCallback {
    void onHideMainBottomContent(Serializable object, int position);
}
