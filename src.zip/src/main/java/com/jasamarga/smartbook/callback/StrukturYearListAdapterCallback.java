package com.jasamarga.smartbook.callback;

/**
 * Created by apridosandyasa on 9/26/16.
 */

public interface StrukturYearListAdapterCallback {
    void ShowPenghargaanListBasedOnYear(int position);
}
