package com.jasamarga.smartbook.callback;

import java.io.Serializable;

/**
 * Created by apridosandyasa on 8/25/16.
 */
public interface HeaderListAdapterCallback {
    void onHeaderListAdapterCallback(Serializable object, int mainMenuId, int position);
}
