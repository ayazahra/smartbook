package com.jasamarga.smartbook.callback;

import java.io.File;

/**
 * Created by apridosandyasa on 8/19/16.
 */
public interface AnggaranFragmentCallback {
    void onAnggaranFragmentCallback(File file);
}
