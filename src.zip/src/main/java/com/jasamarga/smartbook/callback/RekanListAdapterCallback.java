package com.jasamarga.smartbook.callback;

/**
 * Created by apridosandyasa on 8/14/16.
 */
public interface RekanListAdapterCallback {
    void onRekanListAdapterCallback(int position);
}
