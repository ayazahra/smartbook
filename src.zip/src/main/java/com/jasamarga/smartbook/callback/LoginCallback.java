package com.jasamarga.smartbook.callback;

/**
 * Created by apridosandyasa on 9/28/16.
 */

public interface LoginCallback {
    void finishedLoginProcess(String msg, String apiKey);
}
