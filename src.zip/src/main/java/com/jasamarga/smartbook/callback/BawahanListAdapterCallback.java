package com.jasamarga.smartbook.callback;

/**
 * Created by apridosandyasa on 8/13/16.
 */
public interface BawahanListAdapterCallback {
    void onBawahanListAdapterCallback(int position);
}
